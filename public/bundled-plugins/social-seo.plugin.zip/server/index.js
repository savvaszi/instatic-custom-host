const DEFAULT_LOCALE = 'en_CY'

function escapeAttribute(value) {
  return String(value).replace(/[&<>"']/g, (character) => {
    const entities = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }
    return entities[character]
  })
}

function pagePath(slug) {
  const value = String(slug || '').trim().replace(/^\/+|\/+$/g, '')
  if (!value || value === 'home') return '/'
  return `/${value}`
}

function cleanOrigin(value) {
  const origin = String(value || '').trim().replace(/\/+$/, '')
  return /^https:\/\/[a-z0-9.-]+(?::\d+)?$/i.test(origin) ? origin : ''
}

function absoluteUrl(origin, value) {
  const url = String(value || '').trim()
  if (/^https:\/\//i.test(url)) return url
  if (!origin || !url) return ''
  return `${origin}/${url.replace(/^\/+/, '')}`
}

function readOverrides(value) {
  try {
    const parsed = JSON.parse(String(value || '{}'))
    return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : {}
  } catch {
    return {}
  }
}

function readSettings(api) {
  return {
    siteUrl: cleanOrigin(api.cms.settings.get('siteUrl')),
    siteName: String(api.cms.settings.get('siteName') || '').trim(),
    locale: String(api.cms.settings.get('locale') || DEFAULT_LOCALE).trim(),
    defaultTitle: String(api.cms.settings.get('defaultTitle') || '').trim(),
    defaultDescription: String(api.cms.settings.get('defaultDescription') || '').trim(),
    defaultImage: String(api.cms.settings.get('defaultImage') || '').trim(),
    defaultImageAlt: String(api.cms.settings.get('defaultImageAlt') || '').trim(),
    pageOverrides: readOverrides(api.cms.settings.get('pageOverrides')),
  }
}

function metaTag(attribute, key, content) {
  return `  <meta ${attribute}="${key}" content="${escapeAttribute(content)}">`
}

export function injectSocialMetadata(html, context, settings) {
  if (!settings.siteUrl || !settings.siteName || html.includes('property="og:image"')) return html

  const path = pagePath(context.slug)
  const override = settings.pageOverrides[path]
  const page = override && typeof override === 'object' ? override : {}
  const title = String(page.title || settings.defaultTitle || settings.siteName)
  const description = String(page.description || settings.defaultDescription)
  const image = absoluteUrl(settings.siteUrl, page.image || settings.defaultImage)
  const imageAlt = String(page.imageAlt || settings.defaultImageAlt || title)
  const canonical = `${settings.siteUrl}${path === '/' ? '' : path}`
  const tags = [
    metaTag('property', 'og:type', 'website'),
    metaTag('property', 'og:site_name', settings.siteName),
    metaTag('property', 'og:locale', settings.locale || DEFAULT_LOCALE),
    metaTag('property', 'og:title', title),
    metaTag('property', 'og:description', description),
    metaTag('property', 'og:url', canonical),
    image ? metaTag('property', 'og:image', image) : '',
    image ? metaTag('property', 'og:image:alt', imageAlt) : '',
    metaTag('name', 'twitter:card', image ? 'summary_large_image' : 'summary'),
    metaTag('name', 'twitter:title', title),
    metaTag('name', 'twitter:description', description),
    image ? metaTag('name', 'twitter:image', image) : '',
  ].filter(Boolean).join('\n')

  return html.replace('</head>', `${tags}\n</head>`)
}

export default {
  activate(api) {
    api.cms.hooks.filter('publish.html', (html, context) =>
      injectSocialMetadata(html, context, readSettings(api)),
    )
  },
}
