const MAX_ATTEMPTS = 5
const MAX_FIELD_CHARS = 5_000
const MAX_BODY_CHARS = 100_000
const MAX_SMTP_HOST_CHARS = 253

const EMAIL_PATTERN = /^[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+$/

export function isValidHostname(value) {
  const host = String(value || '').trim().toLowerCase()
  if (!host || host.length > MAX_SMTP_HOST_CHARS || /[\r\n]/.test(host)) return false
  if (host === 'localhost' || host.includes(':')) return false
  if (/^\d+(?:\.\d+){3}$/.test(host)) {
    const octets = host.split('.').map(Number)
    if (octets.some((octet) => octet > 255)) return false
    const [first, second] = octets
    return first !== 0 && first !== 10 && first !== 127 && first !== 169 &&
      !(first === 172 && second >= 16 && second <= 31) &&
      !(first === 192 && second === 168)
  }
  return host.split('.').every((label) =>
    label.length > 0 && label.length <= 63 && /^[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/.test(label),
  )
}

export function isValidPort(value) {
  const port = Number(value)
  return Number.isInteger(port) && port >= 1 && port <= 65_535
}

export function isValidTlsMode(value) {
  return value === 'implicit-tls' || value === 'starttls'
}

export function isEligibleSubmission(payload, configuredTable) {
  return Boolean(
    payload &&
      typeof payload === 'object' &&
      payload.tableSlug === configuredTable &&
      payload.actor &&
      payload.actor.kind === 'system' &&
      typeof payload.entryId === 'string' &&
      payload.entryId.length > 0,
  )
}

export function retryDelayMs(attempt) {
  return Math.min(6 * 60 * 60 * 1000, 30_000 * 2 ** Math.max(0, attempt - 1))
}

export function isProviderSuccess(status, body) {
  const data = body && typeof body === 'object' ? body.data : null
  return Boolean(
    status >= 200 &&
      status < 300 &&
      data &&
      Number(data.succeeded) > 0 &&
      Number(data.failed) === 0,
  )
}

export function buildEmail(cells, { subject, recipientEmail, senderEmail }) {
  const fields = Object.entries(cells && typeof cells === 'object' ? cells : {}).slice(0, 100)
  const lines = fields.map(([key, value]) => `${key}: ${displayValue(value)}`)
  const textBody = `New website form submission\n\n${lines.join('\n')}`.slice(0, MAX_BODY_CHARS)
  const htmlRows = fields
    .map(
      ([key, value]) =>
        `<tr><th scope="row">${escapeHtml(key)}</th><td>${escapeHtml(displayValue(value))}</td></tr>`,
    )
    .join('')

  return {
    to: safeEmail(recipientEmail),
    from: safeEmail(senderEmail),
    subject: safeSubject(subject),
    text: textBody,
    html: `<p>New website form submission</p><table><tbody>${htmlRows}</tbody></table>`.slice(
      0,
      MAX_BODY_CHARS,
    ),
  }
}

function displayValue(value) {
  if (value === null || value === undefined) return ''
  if (typeof value === 'string') return value.slice(0, MAX_FIELD_CHARS)
  if (typeof value === 'number' || typeof value === 'boolean') return String(value)
  try {
    return JSON.stringify(value).slice(0, MAX_FIELD_CHARS)
  } catch {
    return '[unavailable]'
  }
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (character) => {
    const entities = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }
    return entities[character]
  })
}

function safeSubject(value) {
  return String(value || 'Website form submission')
    .replace(/[\r\n]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 150) || 'Website form submission'
}

function safeEmail(value) {
  const email = String(value || '').trim()
  return /[\r\n]/.test(email) ? '' : email.slice(0, 320)
}

function readSettings(api) {
  return {
    formTableSlug: String(api.cms.settings.get('formTableSlug') || '').trim(),
    smtpHost: String(api.cms.settings.get('smtpHost') || '').trim(),
    smtpPort: Number(api.cms.settings.get('smtpPort') || 0),
    smtpTlsMode: String(api.cms.settings.get('smtpTlsMode') || '').trim(),
    smtpUsername: String(api.cms.settings.get('smtpUsername') || '').trim(),
    recipientEmail: String(api.cms.settings.get('recipientEmail') || '').trim(),
    senderEmail: String(api.cms.settings.get('senderEmail') || '').trim(),
    subject: String(api.cms.settings.get('subject') || 'Website form submission'),
  }
}

function validEmail(value) {
  return EMAIL_PATTERN.test(value) && !/[\r\n]/.test(value)
}

function settingsReady(settings) {
  return Boolean(
    /^[a-z][a-z0-9-]*$/.test(settings.formTableSlug) &&
      isValidHostname(settings.smtpHost) &&
      isValidPort(settings.smtpPort) &&
      isValidTlsMode(settings.smtpTlsMode) &&
      settings.smtpUsername.length <= 320 &&
      validEmail(settings.recipientEmail) &&
      validEmail(settings.senderEmail),
  )
}

async function enqueue(api, outbox, payload) {
  const settings = readSettings(api)
  if (!settingsReady(settings)) {
    api.plugin.log('SMTP delivery is not configured; form submission left in CMS only.')
    return
  }

  const eventKey = `${payload.tableSlug}:${payload.entryId}`
  const existing = await outbox.list({ filter: { eventKey }, limit: 1 })
  if (existing.records.length > 0) return

  await outbox.create({
    eventKey,
    entryId: payload.entryId,
    tableSlug: payload.tableSlug,
    status: 'queued',
    attempts: 0,
    nextAttemptAt: new Date().toISOString(),
    lastError: '',
    sentAt: '',
  })
}

async function drainQueue(api, outbox) {
  const settings = readSettings(api)
  if (!settingsReady(settings)) return

  const queued = await outbox.list({
    filter: { status: 'queued' },
    limit: 5,
  })

  for (const record of queued.records) {
    const data = record.data
    const dueAt = Date.parse(String(data.nextAttemptAt || ''))
    if (Number.isFinite(dueAt) && dueAt > Date.now()) continue

    try {
      const entry = await api.cms.content.table(settings.formTableSlug).get(String(data.entryId || ''))
      if (!entry) {
        await outbox.update(record.id, { status: 'dead', lastError: 'entry_not_found' })
        continue
      }
      await api.mail.smtp.send(buildEmail(entry.cells, {
        subject: settings.subject,
        recipientEmail: settings.recipientEmail,
        senderEmail: settings.senderEmail,
      }))
      await outbox.update(record.id, {
        status: 'sent',
        sentAt: new Date().toISOString(),
        lastError: '',
      })
    } catch {
      const attempts = Number(data.attempts) + 1
      const permanentlyFailed = attempts >= MAX_ATTEMPTS
      await outbox.update(record.id, {
        status: permanentlyFailed ? 'dead' : 'queued',
        attempts,
        nextAttemptAt: new Date(Date.now() + retryDelayMs(attempts)).toISOString(),
        lastError: 'delivery_failed',
      })
      api.plugin.log(permanentlyFailed ? 'SMTP delivery permanently failed.' : 'SMTP delivery failed; retry queued.')
    }
  }
}

const plugin = {
  activate(api) {
    const outbox = api.cms.storage.collection('mail-outbox')

    api.cms.hooks.on('content.entry.created', async (payload) => {
      const settings = readSettings(api)
      if (!isEligibleSubmission(payload, settings.formTableSlug)) return
      await enqueue(api, outbox, payload)
    })

    api.cms.schedule.register({
      id: 'deliver-mail',
      cadence: { interval: 'every', minutes: 1 },
      overlap: 'skip',
      maxDurationMs: 60_000,
      handler: () => drainQueue(api, outbox),
    })
  },
}

export default plugin
